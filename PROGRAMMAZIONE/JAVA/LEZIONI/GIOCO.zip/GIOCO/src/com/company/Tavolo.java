package com.company;

public class Tavolo {

    // VARIABILI DI ISTANZA
    private static IntSchemeList listaCavalieri;


    Tavolo(int n) {
        // CREA UN TAVOLO CON n CAVALIERE
        // UN TAVOLO PUò ESSERE RAPPRESENTATO DA UNA LISTA DI INTERI
        // IL PRIMO ELEMENTO DELLA LISTA POSSIEDE LA BROCCA
        listaCavalieri = creaListaRange(1,n);
    }
    private Tavolo(IntSchemeList lista){
        listaCavalieri = lista;
    }


    // RESTITUISCE IL NUMERO DI CAVALIERI ATTORNO ALLA TAVOLA
    public static int numeroCavalieri(){
        return listaCavalieri.listLength();
    }

    // CHI HA LA BROCCA?
    // int = identificatore del cavaliere = posizione iniziale quando tavolo creato
    public static int chiHaLaBrocca(){
        return listaCavalieri.car();
    }

    // GIOCO FINITO?? TRUE O FALSE
    public boolean giocoFinito(){
        return listaCavalieri.cdr().isNull();
    }

    // SERVIRE IL SIDRO == FA USCIRE UN CAVALIERE = nuova configurazione del tavolo
    public Tavolo serviSidro(){
        // RIMUOVE SECONDO CAV DELLA LISTA SPARISCE
        IntSchemeList a = listaCavalieri.cdr().cdr().cons(listaCavalieri.car());
        return new Tavolo(a);
    }

    public Tavolo dopoUscita(){
        IntSchemeList coda = IntSchemeList.NULL_INTLIST.cons( listaCavalieri.car());
        IntSchemeList a = listaCavalieri.cdr().cdr().append(coda);
        return new Tavolo(a);
    }


    // PASSA LA BROCCA AL PROSSIMO CAVALIERE
    public static Tavolo passaBrocca(){
        // IL CAV DOPO QUELLO SERVITO OTTIENE LA BROCCA
        // IL PRIMO ELEMENTO VA PER ULTIMO
        // CREA UNA LISTA CON UN SOLO ELEMENTO
        IntSchemeList coda = IntSchemeList.NULL_INTLIST.cons( listaCavalieri.car());
        IntSchemeList b = listaCavalieri.cdr().append(coda);
        return new Tavolo(b);
    }

    private static IntSchemeList creaListaRange(int inf, int sup){
        if (inf > sup) {
            return new IntSchemeList();
        } else {
            return creaListaRange(inf+1, sup).cons(inf);
        }
    }   // SUP >= INF


}    // classe Tavolo
